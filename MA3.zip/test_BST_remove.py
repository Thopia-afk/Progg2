"""
Unittests for the binary search tree methods
"""

import unittest

from bst import *
from linked_list import *


class Test(unittest.TestCase):

    def test_remove(self):
        print('\nTests BST remove')
        print('*** Should be implemented! ***')

        bst = BST()
        for x in [4, 1, 3, 6, 7, 1, 1, 5, 8]:
            bst.insert(x)

        bst.remove(5)
        self.assertEqual(str(bst), '<1, 3, 4, 6, 7, 8>')
        bst.remove(1)
        self.assertEqual(str(bst), '<3, 4, 6, 7, 8>')
        bst.remove(8)
        self.assertEqual(str(bst), '<3, 4, 6, 7>')
        bst.remove(7)
        self.assertEqual(str(bst), '<3, 4, 6>')
        bst.remove(6)
        self.assertEqual(str(bst), '<3, 4>')
        bst.remove(3)
        self.assertEqual(str(bst), '<4>')
        bst.remove(4)
        self.assertEqual(str(bst), '<>')



if __name__ == "__main__":
    unittest.main()
